class ApiConstants {
  // static String baseUrl = 'http://kaavish2023.pythonanywhere.com';
  // http://10.0.2.2:8000
  static String baseUrl = 'http://kaavish2023.pythonanywhere.com';
  static String lifesaverEndpoint = '/lifesaver';
  static String userEndpoint = '/users';
  static String citizenEndpoint = '/citizen';
  static String loginEndpoint = '/login/';
  static String signupEndpoint = '/register';
  static String incidentEndpoint = '/incident';



}